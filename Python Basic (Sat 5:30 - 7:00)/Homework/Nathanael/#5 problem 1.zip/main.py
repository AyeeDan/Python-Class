List = []
print("Blank List: ")
print(List)

List = [10, 20, 14]
print("\nList of numbers: ")
print(List)

List = ["something","for", "cat"]
print("\nList Items: ")
print(List[0])
print(List[2])