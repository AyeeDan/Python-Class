#                   List

#      It is mutable
#The implication of iterations is time-consuming in the list.
#Operations like insertion and deletion are better performed.
#         Consumes more memory.
#
#
#
#
#
#
#
#