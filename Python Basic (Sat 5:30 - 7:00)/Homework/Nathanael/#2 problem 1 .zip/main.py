age = 25
name = "kat"
temperature = 28.5
is_sunny = True

print(f"My age is {age}.")
print(f"My name is {name}.")
print(f"The temperature outside is {temperature} degrees.")
print(f"It is sunny: {is_sunny}")