age_str = input("Please enter your age: ")

# Converting the input to an integer
try:
    age = int(age_str)
    print(f"Your age is {age} years.")
except ValueError:
    print("Invalid input. Please enter a valid age.")