num1 = 122312
num2 = 778787998809

"the sum is"
print(num1 + num2)

"the diffrent is"
print(num1 - num2)

"the product is"
print(num1 * num2)

"the quotient is"
print(num1 / num2)

"the remiander is"
print(num1 % num2)
