Tuple = ()
print("Initial empty Tuple: ")
print(Tuple)

Tuple = ('kat', 'cute')
print("\nTuple with the use of String: ")
print(Tuple)

list1 = [1, 2, 4, 5, 6]
print("\nTuple using List: ")
print(tuple(list1))

Tuple = tuple('kathappy')
print("\nTuple with the use of function: ")
print(Tuple)